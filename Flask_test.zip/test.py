import g4f

request_for_GPT = 'Напиши калькулятор на Python'

def get_response_GPT(request_for_GPT):
    response = g4f.ChatCompletion.create(
        model=g4f.models.default,
        messages=[{"role": "user", "content": request_for_GPT}],
        proxy="http://host:port",

    )
    with open('answer.txt', 'w', encoding='utf-8') as file:
        file.write(response)
    return response

print(f"Result:", get_response_GPT(request_for_GPT))